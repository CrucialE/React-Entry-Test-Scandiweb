export const  COLORS = {
    BLACK: '#1D1F22',
    GREEN: '#5ECE7B',
    WHITE:'#FFFFFF',
    GRAY :'#8D8F9A',

    BACKGROUND:{
     GRAY:'#E5E5E5',

    },

    BORDERS:{
        BLACK:'#000000',
    },

    SPACERbg:{
      GRAY:'#B4D2F4',
    },

    SELECTORbg:{
        GRAY:'#EEEEEE'
    },
    
    PRODUCT_SWATCHES: {
        BLACK: '#2B2B2B',
        GREEN: '#0F6450',
        ORANGE:'#EA8120',
        BLUE:  '#15A4C3',
        GRAY:  '#D3D2D5',
    },

   EMPTY_BASKETbg:{
    BLACK: '#43464E',

   },
   
   
}