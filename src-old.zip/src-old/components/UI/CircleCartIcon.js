import React, { Component } from "react";
import CartIconOnBackground from "../../assets/icons/Circle-Cart-Icon.png";

export default class CircleCartIcon extends Component {
  render() {
    return <img src={CartIconOnBackground} />;
  }
}
